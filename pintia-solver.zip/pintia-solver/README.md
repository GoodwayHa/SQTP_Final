# PTA 刷题助手

一个帮助你解决 PTA 上选择题的小工具.

![](screenshot.png)